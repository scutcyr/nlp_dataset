这是AVEC2018文本数据库

各个文件的解释：
* translatation_check是AVEC2018的抑郁症文本数据库（不是官方提供的，而是Google机器翻译加人工修正）。
* labels_metadata.csv是AVEC2018的抑郁症文本数据库的训练集、验证集、测试集信息
